import java.util.Scanner;

public class Multiplicacao_matriz {
	public static void main(String[] args) {

		/*
		 * Exercicio
		 * 
		 * Multiplicar Matriz
		 *
		 */

		int m1[][] = new int[10][10];
		int m2[][] = new int[10][10];
		int m3[][] = new int[10][10];

		System.out.println("Preencha a matriz 1:");
		Scanner sc = new Scanner(System.in);
		for (int i = 0; i < m1.length; i++) {
			for (int j = 0; j < m1.length; j++) {
				System.out.println("L[" + i + "] C[" + j + "]:");
				m1[i][j]= j;
			}
		}
		System.out.println("Agora, apresentando a matriz1");
		for (int i = 0; i < m1.length; i++) {
			for (int j = 0; j < m1.length; j++) {
				System.out.print(m1[i][j] + " ");
			}
			System.out.println();
		}
		System.out.println("Preencha a matriz 2:");

		for (int i = 0; i < m2.length; i++) {
			for (int j = 0; j < m2.length; j++) {
				System.out.println("L[" + i + "] C[" + j + "]:");
				m2[i][j]= j;
			}
		}
		System.out.println("Agora, apresentando a matriz2");
		for (int i = 0; i < m2.length; i++) {
			for (int j = 0; j < m2.length; j++) {
				System.out.print(m2[i][j] + " ");
			}
			System.out.println();
		}
		System.out.println("Mutiplicando");
		for (int i = 0; i < m1.length; i++) {
			for (int j = 0; j < m2.length; j++) {
				for (int k = 0; k < m1.length; k++) {

					m3[i][j] += (m1[i][k] * m2[k][j]);

				}
				System.out.print(m3[i][j] + " ");
			}
			System.out.println();
		}
	}
}
