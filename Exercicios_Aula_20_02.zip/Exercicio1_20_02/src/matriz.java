import java.util.Scanner;

public class matriz {
	public static void main(String[] args) {
		/*
		 * Declarar uma matriz 10x10 preencher com valores mostrar : diagonal principal
		 * e secundaria triangulo superior e inferior
		 * 
		 */

		int matriz[][] = new int[10][10];

		System.out.println("Preencha essa matriz 10x10:");
		Scanner sc = new Scanner(System.in);
		for (int i = 0; i < 10; i++) {
			for (int j = 0; j < 10; j++) {
				System.out.println("L[" + i + "] C[" + j + "]:");
				matriz[i][j] = sc.nextInt();
			}
		}
		System.out.println("Agora, apresentando a matriz\n\n");
		for (int i = 0; i < 10; i++) {
			for (int j = 0; j < 10; j++) {
				System.out.print(matriz[i][j] + " ");
			}
			System.out.println();
		}
		System.out.println("Diagonal Principal");
		for (int i = 0; i < 10; i++) {
			for (int j = 0; j < 10; j++) {
				if (i == j) {
					System.out.print(matriz[i][j] + " ");
				} else {
					System.out.print("  ");
				}
			}
			System.out.println();
		}
		System.out.println("Diagonal Scundaria");
		for (int i = 0; i < 10; i++) {
			for (int j = 0; j < 10; j++) {
				if (i + j == 2) {
					System.out.print(matriz[i][j] + " ");
				} else {
					System.out.print("  ");
				}
			}
			System.out.println();
		}
		System.out.println("Triangulo superior");
		for (int i = 0; i < 10; i++) {
			for (int j = 0; j < 10; j++) {
				if (i < j) {
					System.out.print(matriz[i][j] + " ");
				} else {
					System.out.print("  ");
				}
			}
			System.out.println();
		}
		System.out.println("Triangulo inferior");
		for (int i = 0; i < 10; i++) {
			for (int j = 0; j < 10; j++) {
				if (i > j) {
					System.out.print(matriz[i][j] + " ");
				} else {
					System.out.print("  ");
				}
			}
			System.out.println();
		}
	}

}
